#!/bin/bash

cmake .
make

echo "AES-COM"
./bin/test_aes_com
echo "SHA3-COM"
./bin/test_sha_com
