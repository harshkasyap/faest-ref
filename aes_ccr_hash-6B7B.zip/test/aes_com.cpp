#include "emp-tool/emp-tool.h"
#include <iostream>
using namespace std;
using namespace emp;
#include <chrono>

//  Windows
#ifdef _WIN32

#include <intrin.h>
uint64_t rdtsc(){
    return __rdtsc();
}

//  Linux/GCC
#else

uint64_t rdtsc(){
    unsigned int lo,hi;
    __asm__ __volatile__ ("rdtsc" : "=a" (lo), "=d" (hi));
    return ((uint64_t)hi << 32) | lo;
}

#endif
#include <time.h>


template <int csp> 
class Test_AES_COM {
public:
    Test_AES_COM (block * hash_input) {
        if (csp == 128) {
            AES_128_Key_Expansion((unsigned char *) &zero_block, (unsigned char *) round_key_1);
            input_buffer[0][0] = hash_input[0];
        } else if (csp == 192 || csp == 256) {
            input_buffer[0][0] = hash_input[0];
            input_buffer[0][1] = hash_input[1];
            memset(user_key_1, 0, sizeof(user_key_1));
            memset(user_key_2, 1, sizeof(user_key_2));
            user_key_1[1] = input_buffer[0][1];
            user_key_2[1] = input_buffer[0][1];
        }
    }
    void run_once (block hash_in[2][2], block hash_out[2][2]) {
        if (csp == 128) {
            block in0 = sigma(hash_in[0][0]);
            block in1 = sigma(hash_in[0][0] ^ all_one_block);
            AES_ECB_encrypt((unsigned char *) &in0,
            (unsigned char *) hash_out[0],
            sizeof(block),
            (const char *) round_key_1,
            10);
            AES_ECB_encrypt((unsigned char *) &in1,
            (unsigned char *) hash_out[1],
            sizeof(block),
            (const char *) round_key_1,
            10);
            hash_out[0][0] = in0 ^ hash_out[0][0];
            hash_out[1][0] = in1 ^ hash_out[1][0];

        } else if (csp == 192) {
            memset(user_key_1, 0, sizeof(block));
            memset(user_key_2, 1, sizeof(block));
            user_key_1[1] = hash_in[0][1];
            user_key_2[1] = hash_in[0][1];
            AES_192_Key_Expansion((unsigned char *) user_key_1, (unsigned char *) round_key_1);
            AES_192_Key_Expansion((unsigned char *) user_key_2, (unsigned char *) round_key_2);
            block in0 = sigma(hash_in[0][0]);
            block in1 = sigma(hash_in[0][0] ^ all_one_block);
            AES_ECB_encrypt((unsigned char *) &in0,
            (unsigned char *) hash_out[0],
            sizeof(block),
            (char *) round_key_1,
            12);

            AES_ECB_encrypt((unsigned char *) &in1,
            (unsigned char *) hash_out[1],
            sizeof(block),
            (char *) round_key_1,
            12);

            AES_ECB_encrypt((unsigned char *) &in0,
            (unsigned char *) hash_out[0] + 1,
            sizeof(block),
            (char *) round_key_2,
            12);
            
            AES_ECB_encrypt((unsigned char *) &in1,
            (unsigned char *) hash_out[1] + 1,
            sizeof(block),
            (char *) round_key_2,
            12);

            hash_out[0][0] = in0 ^ hash_out[0][0];
            hash_out[0][1] = in0 ^ hash_out[0][1];
            hash_out[1][0] = in1 ^ hash_out[1][0];
            hash_out[1][1] = in1 ^ hash_out[1][1];

        } else if (csp == 256) {
            memset(user_key_1, 0, sizeof(block));
            memset(user_key_2, 1, sizeof(block));
            user_key_1[1] = hash_in[0][1];
            user_key_2[1] = hash_in[0][1];
            AES_256_Key_Expansion((unsigned char *) user_key_1, (unsigned char *) round_key_1);
            AES_256_Key_Expansion((unsigned char *) user_key_2, (unsigned char *) round_key_2);
            block in0 = sigma(hash_in[0][0]);
            block in1 = sigma(hash_in[0][0] ^ all_one_block);
            AES_ECB_encrypt((unsigned char *) &in0,
            (unsigned char *) hash_out[0],
            sizeof(block),
            (char *) round_key_1,
            14);

            AES_ECB_encrypt((unsigned char *) &in1,
            (unsigned char *) hash_out[1],
            sizeof(block),
            (char *) round_key_1,
            14);

            AES_ECB_encrypt((unsigned char *) &in0,
            (unsigned char *) hash_out[0] + 1,
            sizeof(block),
            (char *) round_key_2,
            14);
            
            AES_ECB_encrypt((unsigned char *) &in1,
            (unsigned char *) hash_out[1] + 1,
            sizeof(block),
            (char *) round_key_2,
            14);

            hash_out[0][0] = in0 ^ hash_out[0][0];
            hash_out[0][1] = in0 ^ hash_out[0][1];
            hash_out[1][0] = in1 ^ hash_out[1][0];
            hash_out[1][1] = in1 ^ hash_out[1][1];
        }
    }

    void run (int count) {
        while (count--) {
            run_once(input_buffer, output_buffer);
        }
    }

    void run_left_or_right (int count) {
        bool direction = true;
        while (count--) {
            run_left_or_right_once(direction);
            direction = !direction;
        }
    }

    void run_left_or_right_once (bool direction) {
        if (direction == true) {
            run_once(input_buffer, output_buffer);
        } else {
            run_once(output_buffer, input_buffer);
        }
    }

private:
    block user_key_1 [2];
    block user_key_2 [2];
    block round_key_1 [15];
    block round_key_2 [15];
    block input_buffer [2][2];
    block output_buffer [2][2];

};

int main() {
    using namespace std::chrono;
    auto start = high_resolution_clock::now();
    auto end = high_resolution_clock::now();
    auto duration = duration_cast<nanoseconds>(end - start);
    uint64_t clock_start, clock_end;
    double clock_average;


    uint64_t CCR_RUN_COUNT = 100000000;
    block hash_input[2];
    hash_input[0] = makeBlock(0xffeeddccbbaa9988, 0x7766554433221100);
    hash_input[1] = hash_input[0];

    Test_AES_COM<128> ccr_aes_128 (hash_input);
    Test_AES_COM<192> ccr_aes_192 (hash_input);
    Test_AES_COM<256> ccr_aes_256 (hash_input);

    clock_start = rdtsc();
    ccr_aes_128.run_left_or_right(CCR_RUN_COUNT);
    clock_end = rdtsc();
    clock_average = (clock_end - clock_start) / (double) CCR_RUN_COUNT;
    cout << "COM_CCR_AES128: " << clock_average << " cycle " << endl;

    clock_start = rdtsc();
    ccr_aes_192.run_left_or_right(CCR_RUN_COUNT);
    clock_end = rdtsc();
    clock_average = (clock_end - clock_start) / (double) CCR_RUN_COUNT;
    cout << "COM_CCR_AES192: " << clock_average << " cycle " << endl;

    clock_start = rdtsc();
    ccr_aes_256.run_left_or_right(CCR_RUN_COUNT);
    clock_end = rdtsc();
    clock_average = (clock_end - clock_start) / (double) CCR_RUN_COUNT;
    cout << "COM_CCR_AES256: " << clock_average << " cycle " << endl;
    
    start = high_resolution_clock::now();
    ccr_aes_128.run_left_or_right(CCR_RUN_COUNT);
    end = high_resolution_clock::now();
    duration = duration_cast<nanoseconds>(end - start);
    cout << "COM_CCR_AES128: " << duration.count() / (double) CCR_RUN_COUNT << " ns " << endl;

    start = high_resolution_clock::now();
    ccr_aes_192.run_left_or_right(CCR_RUN_COUNT);
    end = high_resolution_clock::now();
    duration = duration_cast<nanoseconds>(end - start);
    cout << "COM_CCR_AES192: " << duration.count() / (double) CCR_RUN_COUNT << " ns " << endl;


    start = high_resolution_clock::now();
    ccr_aes_256.run_left_or_right(CCR_RUN_COUNT);
    end = high_resolution_clock::now();
    duration = duration_cast<nanoseconds>(end - start);
    cout << "COM_CCR_AES256: " << duration.count() / (double) CCR_RUN_COUNT << " ns " << endl;


	return 0;
}
