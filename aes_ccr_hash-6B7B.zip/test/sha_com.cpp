#include "emp-tool/emp-tool.h"
#include <iostream>
#include <chrono>

using namespace std;
using namespace emp;

//  Windows
#ifdef _WIN32

#include <intrin.h>
uint64_t rdtsc(){
    return __rdtsc();
}

//  Linux/GCC
#else

uint64_t rdtsc(){
    unsigned int lo,hi;
    __asm__ __volatile__ ("rdtsc" : "=a" (lo), "=d" (hi));
    return ((uint64_t)hi << 32) | lo;
}

#endif
#include <time.h>



template <int csp> 
class Test_SHA_COM {
public:
    Test_SHA_COM (block * hash_input) {
        if (csp == 128) {
            input_buffer[0][0] = hash_input[0];
        } else if (csp == 192 || csp == 256) {
            input_buffer[0][0] = hash_input[0];
            input_buffer[0][1] = hash_input[1];
        }
    }
    void run_once (block hash_in[2][2], block hash_out[2][2]) {
        if (csp == 128) {
            sha3_256<block> ((uint8_t*) hash_out[0], hash_in[0], 1);
        } else if (csp == 192) {
            sha3_384<block> ((uint8_t*) hash_out[0], hash_in[0], 2);
        } else if (csp == 256) {
            sha3_512<block> ((uint8_t*) hash_out[0], hash_in[0], 2);
        }
    }

    void run (int count) {
        while (count--) {
            run_once(input_buffer, output_buffer);
        }
    }

    void run_left_or_right (int count) {
        bool direction = true;
        while (count--) {
            run_left_or_right_once(direction);
            direction = !direction;
        }
    }

    void run_left_or_right_once (bool direction) {
        if (direction == true) {
            run_once(input_buffer, output_buffer);
        } else {
            run_once(output_buffer, input_buffer);
        }
    }

private:
    block input_buffer [2][2];
    block output_buffer [2][2];

};

int main () {
    using namespace std::chrono;
    auto start = high_resolution_clock::now();
    auto end = high_resolution_clock::now();
    auto duration = duration_cast<nanoseconds>(end - start);
    uint64_t clock_start, clock_end;
    double clock_average;


    uint64_t CCR_RUN_COUNT = 1000000;
    block hash_input[2];
    hash_input[0] = makeBlock(0xffeeddccbbaa9988, 0x7766554433221100);
    hash_input[1] = hash_input[0];

    // test for ccr_aes_128
    Test_SHA_COM<128> com_sha_128 (hash_input);

    // test for ccr_aes_192
    Test_SHA_COM<192> com_sha_192 (hash_input);

    // test for ccr_aes_256
    Test_SHA_COM<256> com_sha_256 (hash_input);

    clock_start = rdtsc();
    com_sha_128.run_left_or_right(CCR_RUN_COUNT);
    clock_end = rdtsc();
    clock_average = (clock_end - clock_start) / (double) CCR_RUN_COUNT;
    cout << "COM_SHA3_128: " << clock_average << " cycle " << endl;

    clock_start = rdtsc();
    com_sha_192.run_left_or_right(CCR_RUN_COUNT);
    clock_end = rdtsc();
    clock_average = (clock_end - clock_start) / (double) CCR_RUN_COUNT;
    cout << "COM_SHA3_192: " << clock_average << " cycle " << endl;

    clock_start = rdtsc();
    com_sha_256.run_left_or_right(CCR_RUN_COUNT);
    clock_end = rdtsc();
    clock_average = (clock_end - clock_start) / (double) CCR_RUN_COUNT;
    cout << "COM_SHA3_256: " << clock_average << " cycle " << endl;

    start = high_resolution_clock::now();
    com_sha_128.run_left_or_right(CCR_RUN_COUNT);
    end = high_resolution_clock::now();
    duration = duration_cast<nanoseconds>(end - start);
    cout << "COM_SHA3_128: " << duration.count() / (double) CCR_RUN_COUNT << " ns " << endl;
    

    start = high_resolution_clock::now();
    com_sha_192.run_left_or_right(CCR_RUN_COUNT);
    end = high_resolution_clock::now();
    duration = duration_cast<nanoseconds>(end - start);
    cout << "COM_SHA3_192: " << duration.count() / (double) CCR_RUN_COUNT << " ns " << endl;

    start = high_resolution_clock::now();
    com_sha_256.run_left_or_right(CCR_RUN_COUNT);
    end = high_resolution_clock::now();
    duration = duration_cast<nanoseconds>(end - start);
    cout << "COM_SHA3_256: " << duration.count() / (double) CCR_RUN_COUNT << " ns " << endl;


	return 0;

}