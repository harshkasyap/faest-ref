#include "emp-tool/emp-tool.h"
#include <iostream>
using namespace std;
using namespace emp;
#include <chrono>


//  Windows
#ifdef _WIN32

#include <intrin.h>
uint64_t rdtsc(){
    return __rdtsc();
}

//  Linux/GCC
#else

uint64_t rdtsc(){
    unsigned int lo,hi;
    __asm__ __volatile__ ("rdtsc" : "=a" (lo), "=d" (hi));
    return ((uint64_t)hi << 32) | lo;
}

#endif


template <int csp> 
class Test_AES_CCR {
public:
    Test_AES_CCR (block * hash_input) {
        if (csp == 128) {
            AES_128_Key_Expansion((unsigned char *) &zero_block, (unsigned char *) round_key_1);
            input_buffer[0] = hash_input[0];
        } else if (csp == 192 || csp == 256) {
            input_buffer[0] = hash_input[0];
            input_buffer[1] = hash_input[1];
            memset(user_key_1, 0, sizeof(user_key_1));
            memset(user_key_2, 1, sizeof(user_key_2));
            user_key_1[1] = input_buffer[1];
            user_key_2[1] = input_buffer[1];
        }
    }
    void run_once (block *hash_in, block *hash_out) {
        if (csp == 128) {
            block in = sigma(hash_in[0]);
            AES_ECB_encrypt((unsigned char *) &in,
            (unsigned char *) hash_out,
            sizeof(block),
            (const char *) round_key_1,
            10);
            hash_out[0] = in ^ hash_out[0];

        } else if (csp == 192) {
            memset(user_key_1, 0, sizeof(block));
            memset(user_key_2, 1, sizeof(block));
            user_key_1[1] = hash_in[1];
            user_key_2[1] = hash_in[1];
            AES_192_Key_Expansion((unsigned char *) user_key_1, (unsigned char *) round_key_1);
            AES_192_Key_Expansion((unsigned char *) user_key_2, (unsigned char *) round_key_2);
            memcpy(user_key_2, user_key_1, sizeof(user_key_1));
            block in = sigma(hash_in[0]);
            AES_ECB_encrypt((unsigned char *) &in,
            (unsigned char *) hash_out,
            sizeof(block),
            (char *) round_key_1,
            12);
            AES_ECB_encrypt((unsigned char *) &in,
            (unsigned char *) hash_out + 1,
            sizeof(block),
            (char *) round_key_2,
            12);
            hash_out[0] = in ^ hash_out[0];
            hash_out[1] = in ^ hash_out[1];
        } else if (csp == 256) {
            memset(user_key_1, 0, sizeof(block));
            memset(user_key_2, 1, sizeof(block));
            user_key_1[1] = hash_in[1];
            user_key_2[1] = hash_in[1];
            AES_256_Key_Expansion((unsigned char *) user_key_1, (unsigned char *) round_key_1);
            AES_256_Key_Expansion((unsigned char *) user_key_2, (unsigned char *) round_key_2);
            block in = sigma(hash_in[0]);
            AES_ECB_encrypt((unsigned char *) &in,
            (unsigned char *) hash_out,
            sizeof(block),
            (char *) round_key_1,
            14);
            AES_ECB_encrypt((unsigned char *) &in,
            (unsigned char *) hash_out + 1,
            sizeof(block),
            (char *) round_key_2,
            14);
            hash_out[0] = in ^ hash_out[0];
            hash_out[1] = in ^ hash_out[1];
        }
    }

    void run (int count) {
        while (count--) {
            run_once(input_buffer, output_buffer);
        }
    }

    void run_left_or_right (int count) {
        bool direction = true;
        while (count--) {
            run_left_or_right_once(direction);
            direction = !direction;
        }
    }

    void run_left_or_right_once (bool direction) {
        if (direction == true) {
            run_once(input_buffer, output_buffer);
        } else {
            run_once(output_buffer, input_buffer);
        }
    }

private:
    block user_key_1 [2];
    block user_key_2 [2];
    block round_key_1 [15];
    block round_key_2 [15];
    block input_buffer [2];
    block output_buffer [2];

};

void test_chrono () {
    using namespace std::chrono;
    auto start = high_resolution_clock::now();
    auto end = high_resolution_clock::now();
    auto duration = duration_cast<nanoseconds>(end - start);


    uint64_t CCR_RUN_COUNT = 100000000;
    block hash_input[2];
    hash_input[0] = makeBlock(0xffeeddccbbaa9988, 0x7766554433221100);
    hash_input[1] = hash_input[0];

    // test for ccr_aes_128
    Test_AES_CCR<128> ccr_aes_128 (hash_input);
    start = high_resolution_clock::now();
    ccr_aes_128.run_left_or_right(CCR_RUN_COUNT);
    end = high_resolution_clock::now();
    duration = duration_cast<nanoseconds>(end - start);
    cout << "CCR_AES128: " << duration.count() / (double) CCR_RUN_COUNT << " ns " << endl;

    
    // test for ccr_aes_192
    Test_AES_CCR<192> ccr_aes_192 (hash_input);
    start = high_resolution_clock::now();
    ccr_aes_192.run_left_or_right(CCR_RUN_COUNT);
    end = high_resolution_clock::now();
    duration = duration_cast<nanoseconds>(end - start);
    cout << "CCR_AES192: " << duration.count() / (double) CCR_RUN_COUNT << " ns " << endl;

    // test for ccr_aes_256
    Test_AES_CCR<256> ccr_aes_256 (hash_input);
        start = high_resolution_clock::now();
    ccr_aes_256.run_left_or_right(CCR_RUN_COUNT);
    end = high_resolution_clock::now();
    duration = duration_cast<nanoseconds>(end - start);
    cout << "CCR_AES256: " << duration.count() / (double) CCR_RUN_COUNT << " ns " << endl;

}

void test_rdtsc() {
    uint64_t start, end;
    double average;


    uint64_t CCR_RUN_COUNT = 100000000;
    block hash_input[2];
    hash_input[0] = makeBlock(0xffeeddccbbaa9988, 0x7766554433221100);
    hash_input[1] = hash_input[0];

    // test for ccr_aes_128
    Test_AES_CCR<128> ccr_aes_128 (hash_input);
    start = rdtsc();
    ccr_aes_128.run_left_or_right(CCR_RUN_COUNT);
    end = rdtsc();
    average = (end - start) / (double) CCR_RUN_COUNT;
    cout << "CCR_AES128: " << average << " cycles " << endl;

    
    // test for ccr_aes_192
    Test_AES_CCR<192> ccr_aes_192 (hash_input);
    start = rdtsc();
    ccr_aes_192.run_left_or_right(CCR_RUN_COUNT);
    end = rdtsc();
    average = (end - start) / (double) CCR_RUN_COUNT;
    cout << "CCR_AES192: " << average << " cycles " << endl;

    // test for ccr_aes_256
    Test_AES_CCR<256> ccr_aes_256 (hash_input);
    start = rdtsc();
    ccr_aes_256.run_left_or_right(CCR_RUN_COUNT);
    end = rdtsc();
    average = (end - start) / (double) CCR_RUN_COUNT;
    cout << "CCR_AES256: " << average << " cycles " << endl;
}

int main() {
    
    test_rdtsc();

    test_chrono();

	return 0;
}
