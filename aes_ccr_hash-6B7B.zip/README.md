# Extractable CCR Hash from Standard AES

This repository is a fork of [emp-tool](https://github.com/emp-toolkit/emp-tool). Therefore, to run the following benchmarks, please follow the instructions there to install necessary prerequisites.

## Benchmark 1: AES CCR vs Rijndael CCR

Implementation: `test/aes_opt2.cpp`, `emp-tool/utils/faest_em_192s/api_test.c`, and `emp-tool/utils/faest_em_256s/api_test.c`.

How to run: (shortcut: `bash run_ccr_bench.sh`)
- To test the speed of the AES-CCR hash, go to the `emp-tool` directory and run `cmake . && make && ./bin/test_aes2`
- To test the speed of Rijndael-192 hash, go to the `emp-tool/utils/faest_em_192s` directory and run `make && ./api_test`
- To test the speed of Rijndael-256 hash, go to the `emp-tool/utils/faest_em_256s` directory and run `make && ./api_test`

Note that Rijndael128=AES128 and the AES-CCR and MMO constructions converge in this case, therefore, we did not implement the benchmark code
for Rijndael128.
The Rijndael implementation is adapted from faest-ref and their build system does not seem to integrate easily with the emp-tool's counterpart.
Therefore, I simply copied their code verbatim.

Additionally, it's worth noting that FAEST provided different APIs for Rijndael192 and Rijndael256. In Rijndael192 the FAEST team implmented a separate `rijndael192_encrypt_block` function for the complete 12-round `rijndael192` encryption while in Rijndael256 they implemented the `rijndael256_round` function for a single round.

## Benchmark 2: AES CCR Commitment vs SHA3 Commitment

Implementation: `test/sha_com.cpp` and `test/aes_com.cpp`.

How to run: (shortcut: `bash run_com_bench.sh`)
- To test the speed of SHA3-based commitment, go to the `emp-tool` directory and run `cmake . && make && ./bin/test_sha_com`
- To test the speed of AES-based commitment, go to the `emp-tool` directory and run `cmake . && make && ./bin/test_aes_com`