#!/bin/bash

cmake .
make
cd emp-tool/utils
cd faest_em_192s
make 
cd ..
cd faest_em_256s
make
cd ..
cd ../..

echo "AES-CCR"
./bin/test_aes_opt2
echo "Rijndael192-CCR"
./emp-tool/utils/faest_em_192s/api_test
echo "Rijndael256-CCR"
./emp-tool/utils/faest_em_256s/api_test
