#include "vole_params.h"

extern inline void init_fixed_keys(
	prg_tree_fixed_key* fixed_key_tree, prg_leaf_fixed_key* fixed_key_leaf,
	block_secpar iv);
